"use strict";
cc._RF.push(module, '355ffopD5ZHd4ZZTRyYt0Io', 'ConstValue');
// Script/Model/ConstValue.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
/**
 * 这个脚本用来存储一些全局都会用到的常量
 */
var GAME_INFO = {};

var GAME_STATUS = {
    DISABLED: 0,
    CAN_CLICK1: 1
};

exports.GAME_INFO = GAME_INFO;
exports.GAME_STATUS = GAME_STATUS;

cc._RF.pop();