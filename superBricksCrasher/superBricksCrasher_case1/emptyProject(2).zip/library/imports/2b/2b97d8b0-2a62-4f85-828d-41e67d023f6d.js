"use strict";
cc._RF.push(module, '2b97diwKmJPhYKNQeZ9Aj9t', 'GameView');
// Script/Views/GameView.js

"use strict";

var _ConstValue = require("../Model/ConstValue");

var _Animation = require("../Utils/Animation");

var _utils = require("../Utils/utils");

cc.Class({
  extends: cc.Component,

  properties: {
    mask: { type: cc.Node, default: null },
    bghand: { type: cc.Node, default: null },
    hand: { type: cc.Node, default: null },
    pp: { type: cc.Prefab, default: null },
    ppIcon: { type: cc.Node, default: null },
    pps: { type: cc.Node, default: null }
  },

  // 生命周期回调函数------------------------------------------------------------------------
  /**onLoad会比start快 */
  onLoad: function onLoad() {
    window.GameView = this;
    this.gameViewInit();
    this.handClip = this.hand.getComponent(cc.Animation);
    // 设置进度条全局变量
    this.timeBegin = 0;
    // 设置金额全局变量
    // this.cashBegin = 0;
    // this.cashView.addCash(150,1);
  },
  start: function start() {
    // this.cashView.setIcon("$ ", "head");
    // this.showHandDrag();
    this.addEventListener();
    // this.setGameStatus(GAME_STATUS);
    // 开启动画
    this.bghand.active = true;
    this.handClip.play();
  },

  // 生命周期函数结束---------------------------------------------------------------------

  // 工具函数----------------------------------------------------------------------------
  /**设置游戏状态 */
  setGameStatus: function setGameStatus(status) {
    this.gameInfo.status = status;
  },
  getGameStatus: function getGameStatus() {
    return this.gameInfo.status;
  },
  getMoneyMusicThrottle: function getMoneyMusicThrottle() {
    var _this = this;

    return (0, _utils.getThrottle)(function () {
      _this.audioUtils.playEffect("money");
    }, 50);
  },
  getFreshMusicThrottle: function getFreshMusicThrottle() {
    var _this2 = this;

    return (0, _utils.getThrottle)(function () {
      _this2.audioUtils.playEffect("fresh", 0.2);
    }, 100);
  },
  getCombineMusicThrottle: function getCombineMusicThrottle() {
    var _this3 = this;

    return (0, _utils.getThrottle)(function () {
      _this3.audioUtils.playEffect("combine", 0.3);
    }, 100);
  },
  getCorrectMusicThrottle: function getCorrectMusicThrottle() {
    var _this4 = this;

    return (0, _utils.getThrottle)(function () {
      _this4.audioUtils.playEffect("correct", 0.3);
    }, 100);
  },
  getCheerMusicThrottle: function getCheerMusicThrottle() {
    var _this5 = this;

    return (0, _utils.getThrottle)(function () {
      _this5.audioUtils.playEffect("cheer", 0.3);
    }, 100);
  },

  /**初始化游戏参数 */
  gameViewInit: function gameViewInit() {
    // 初始化参数
    this.gameInfo = {
      status: _ConstValue.GAME_STATUS.DISABLED // 初始设置为不可点击状态
    };

    // 获得脚本
    this.gameController.setScript(this, "audioUtils", "guideView", "awardView", "progressView", "cashView");

    this.playFreshMusicByThrottle = this.getFreshMusicThrottle();
    this.playCombineMusicByThrottle = this.getCombineMusicThrottle();
    this.playMoneyMusicByThrottle = this.getMoneyMusicThrottle();
    this.playCorrectMusicByThrottle = this.getCorrectMusicThrottle();
    this.playCheerMusicByThrottle = this.getCheerMusicThrottle();
  },


  /**切换mask的显示状态
   * @param type 如果为 in 则表示显示 如果为out 则表示隐藏
   */
  toggleGameMask: function toggleGameMask(type) {
    return (0, _Animation.toggleMask)(this.mask, type);
  },

  // 工具函数结束---------------------------------------------------------------------------

  // 点击事件相关-------------------------------------------------------------------------
  /**增加点击事件 */
  addEventListener: function addEventListener() {
    this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
    this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
    this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
    this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this);
  },


  /**点击事件start */
  onTouchStart: function onTouchStart(e) {
    // this.gameController.getAudioUtils().playEffect('bgClick', 0.8);
    // 关闭动画
    this.handClip.pause();
    this.hand.active = false;
    this.bghand.active = false;
  },


  /**点击事件移动 */
  onTouchMove: function onTouchMove(e) {},


  /**点击事件结束 */
  onTouchEnd: function onTouchEnd(e) {},


  /**
   * 判断点击是否在node里面
   * @param {*} e 点击事件
   * @param {cc.Node} node 判断点击事件是否在里面的节点
   * @returns {Boolean}
   */
  checkPosByNode: function checkPosByNode(e, node) {
    var touchPos = e.touch._point;
    var pos = node.parent.convertToWorldSpaceAR(node.position);
    var offsetX = node.width / 2;
    var offsetY = node.height / 2;

    if (touchPos.x <= pos.x + offsetX && touchPos.x >= pos.x - offsetX && touchPos.y <= pos.y + offsetY && touchPos.y >= pos.y - offsetY) {
      // console.log('在里面')
      return true;
    } else {
      // console.log('不在里面');
      return false;
    }
  },

  // 点击事件相关结束---------------------------------------------------------------------

  // guide相关----------------------------------------------------------------------------
  /**显示手 */
  showHand: function showHand(node, type) {
    this.guideView.showHand(node, type);
  },


  /**显示拖拽手 */
  showHandDrag: function showHandDrag(nodeArr, type) {
    this.guideView.showHandDrag(nodeArr, type);
  },


  // guide相关结束---------------------------------------------------------------------------

  // award相关--------------------------------------------------------------------------------
  /**展示奖励页 */
  showAwardPage: function showAwardPage() {
    // console.log('展示奖励页~')
    this.awardView.showAwardPage();
  },

  // award相关结束-----------------------------------------------------------------------------

  /**获取两点的直线距离 */
  getDistance: function getDistance(pos1, pos2) {
    return {
      x: Math.floor(Math.abs(pos1.x - pos2.x)),
      y: Math.floor(Math.abs(pos1.y - pos2.y))
    };
  },


  /**
   * 展示pp卡
   * @param {Node} startPosition 
   * @returns 
   */
  showPps: function showPps(startPosition) {
    var _this6 = this;

    return new Promise(function (resolve, reject) {
      var isPlayMusic = false;
      // 使用这个可以控制pp卡飞向终点的先后效果

      var _loop = function _loop(i) {
        if (!isPlayMusic) {
          isPlayMusic = true;
          _this6.audioUtils.playEffect("money");
        }
        var pp = cc.instantiate(_this6.pp);
        pp.active = false;
        pp.scale = 0;
        pp.parent = _this6.pps;
        // pp.position = cc.v2(200, 0);
        pp.position = startPosition;
        (0, _Animation.scaleIn)(pp).then(function () {
          setTimeout(function () {
            (0, _Animation.flyTo)(pp, _this6.ppIcon).then(function () {
              _this6.playMoneyMusicByThrottle();
              resolve();
            });
          }, 100 * i);
        });
      };

      for (var i = 0; i < 5; i++) {
        _loop(i);
      }
    });
  }
});

cc._RF.pop();