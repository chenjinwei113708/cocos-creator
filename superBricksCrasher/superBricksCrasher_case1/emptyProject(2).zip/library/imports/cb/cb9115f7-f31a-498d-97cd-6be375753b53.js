"use strict";
cc._RF.push(module, 'cb911X38xpJjZfNa+N1dTtT', 'DownloadUrl');
// Script/Utils/DownloadUrl.js

'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
var DownloadUrl = exports.DownloadUrl = {
    iosUrl: 'https://apps.apple.com/app/id1547566715',
    androidUrl: 'https://apps.apple.com/app/id1547566715',

    getUrl: function getUrl() {
        var userAgent = navigator.userAgent || navigator.vendor;
        if (/(iPhone|iPad|iPod|iOS|Mac OS X)/i.test(userAgent)) {
            userAgent = 'ios';
        } else {
            userAgent = 'android';
        }
        return userAgent === 'ios' ? this.iosUrl : this.androidUrl;
    }
};

cc._RF.pop();