"use strict";
cc._RF.push(module, 'a6a37drh7lOoLoiUv4IOcIl', 'TurnView');
// Script/Views/TurnView.js

'use strict';

var _ConstValue = require('../Model/ConstValue');

var _Animation = require('../Utils/Animation');

cc.Class({
    extends: cc.Component,

    properties: {
        content: { type: cc.Node, default: null },
        tip_turn: { type: cc.Node, default: null },
        mask: { type: cc.Node, default: null }
    },

    onLoad: function onLoad() {
        this.turnViewInit();
    },
    start: function start() {
        this.guideView.showHand(this.tip_turn);
        // 设置为可以点击的状态
        this.gameView.setGameStatus(_ConstValue.GAME_STATUS.CAN_SPIN);
    },


    /**初始化函数 */
    turnViewInit: function turnViewInit() {
        // 获取脚本
        this.gameController.setScript(this, 'gameView', 'audioUtils', 'guideView', 'awardView');

        // 初始化参数
        this.currentAngle = 0; // 表示已经旋转的角度
        this.turnNumber = 5; // 表示一共转多少圈
        this.itemAngle = {
            item1: 0,
            item2: 60,
            item3: 120,
            item4: 180,
            item5: 240,
            item6: 300
        };
        this.endItem = 'item3';

        // 初始化位置与状态
        // this.mask.opacity = 125;
        // this.mask.active = true;
        // this.turn.active = true;
    },


    /**隐藏转盘 */
    hideTurn: function hideTurn(cb) {
        this.toggleMask('out');
        (0, _Animation.slideOut)(this.node).then(function () {
            cb && cb();
        });
    },


    /**开始旋转 */
    startSpin: function startSpin(e) {
        var _this = this;

        var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'item3';

        if (this.gameView.getGameStatus() !== _ConstValue.GAME_STATUS.CAN_SPIN) return false;
        this.gameView.setGameStatus(_ConstValue.GAME_STATUS.DISABLED);
        this.guideView.stopHand();
        this.audioUtils.playEffect('spin');

        return new Promise(function (resolve, reject) {
            var spinTime = 3.3;
            _this.content.runAction(cc.sequence(cc.rotateBy(spinTime, 360 * _this.turnNumber - _this.itemAngle[_this.endItem]).easing(cc.easeInOut(4)), cc.callFunc(function () {})));
        });
    },


    /** 旋转之后的回调 */
    spinCallback: function spinCallback() {
        this.toggleMask('out');
        this.gameView.setGameStatus(_ConstValue.GAME_STATUS.CAN_RECEIVE1);
    },


    /**切换显示遮罩层 */
    toggleTurnMask: function toggleTurnMask(type) {
        return (0, _Animation.toggleMask)(this.mask, type);
    }
});

cc._RF.pop();