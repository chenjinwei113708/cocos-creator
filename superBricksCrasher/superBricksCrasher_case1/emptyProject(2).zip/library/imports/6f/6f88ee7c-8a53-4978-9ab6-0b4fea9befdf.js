"use strict";
cc._RF.push(module, '6f88e58ilNJeJq2C0/qm+/f', 'GameController');
// Script/Controller/GameController.js

"use strict";

var _GameModel = require("../Model/GameModel");

var _GameModel2 = _interopRequireDefault(_GameModel);

var _PlayformSDK = require("../Utils/PlayformSDK");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

cc.Class({
    extends: cc.Component,
    properties: {
        center: cc.Node, // 横竖屏适配

        game: cc.Node, // 游戏主要部分
        audio: cc.Node, // 音频
        guide: cc.Node, // 引导
        cash: cc.Node, // 金币 / 分数
        award: cc.Node, // 奖励相关
        progress: cc.Node, // 进度条
        countDown: cc.Node, // 倒计时
        turn: cc.Node // 转盘
    },

    onLoad: function onLoad() {
        // 游戏开始 等待平台SDK加载后调用gameInit
        _PlayformSDK.PlayformSDK.gameStart();
    },
    gameInit: function gameInit() {
        // cc.director.setDisplayStats(false);
        //是否显示左下方fps信息
        cc.debug.setDisplayStats(false);

        // GameModel初始化
        this.gameModel = new _GameModel2.default();
        this.gameModel.gameInit();

        // 获取脚本
        this.gameView = this.game.getComponent('GameView');
        this.guideView = this.guide.getComponent('GuideView');
        this.cashView = this.cash.getComponent('CashView');
        this.centerScript = this.center.getComponent("CenterView");
        this.audioUtils = this.audio.getComponent('AudioUtils');
        this.awardView = this.award.getComponent('AwardView');
        this.progressView = this.progress.getComponent('ProgressView');
        this.countDownView = this.countDown.getComponent('CountDownView');
        this.turnView = this.turn.getComponent('TurnView');

        console.log(this.turnView);
        // 设置gameController引用
        this.setGameController(this.gameView, this.guideView, this.cashView, this.centerScript, this.audioUtils, this.awardView, this.progressView, this.countDownView, this.turnView);

        // 根据model渲染各个元素状态 大小 位置等
        this.centerScript.initWithModel(this.gameModel);

        // 监听横竖屏变化
        if (typeof dapi !== 'undefined') {
            // IS平台使用媒体查询事件
            var mql = window.matchMedia("(orientation: portrait)");
            mql.addListener(this.centerScript.orientCb.bind(this.centerScript, true));
        } else {
            window.addEventListener("resize", this.centerScript.orientCb.bind(this.centerScript, true));
        }

        // 数据加载完毕
        _PlayformSDK.PlayformSDK.gameReady();
    },


    /**设置脚本绑定gameController引用 */
    setGameController: function setGameController() {
        var _this = this;

        for (var _len = arguments.length, scripts = Array(_len), _key = 0; _key < _len; _key++) {
            scripts[_key] = arguments[_key];
        }

        scripts.forEach(function (script) {
            script.gameController = _this;
        });
    },


    /**
     * 用来绑定脚本之间的相互引用
     * @param {*} that 需要绑定的脚本this
     * @param {*} scriptName 脚本名字
     */
    setScript: function setScript(that) {
        var _this2 = this;

        for (var _len2 = arguments.length, scriptNames = Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
            scriptNames[_key2 - 1] = arguments[_key2];
        }

        scriptNames.forEach(function (scriptName) {
            that[scriptName] = _this2[scriptName];
        });
    },


    /**调用下载方法 */
    download: function download() {
        this.endGame();
        _PlayformSDK.PlayformSDK.download();
    },


    /**调用结束游戏时的方法 */
    endGame: function endGame() {
        _PlayformSDK.PlayformSDK.gameFinish();
    }
});

cc._RF.pop();