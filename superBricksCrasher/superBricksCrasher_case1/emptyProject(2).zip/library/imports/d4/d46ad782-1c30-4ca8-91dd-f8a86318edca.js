"use strict";
cc._RF.push(module, 'd46adeCHDBMqJHd+KhjGO3K', 'GameModel');
// Script/Model/GameModel.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

require("./ConstValue");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

// import SandModel from "./SandModel";

var GameModel = function () {
    // state
    function GameModel() {
        _classCallCheck(this, GameModel);

        // 初始化state
        // 横竖屏参数
        this.isLandscape = false;
        this.isMintegral = true; // 检测是不是isMintegral平台
        this.isApplovin = false; // 是不是applovin平台
        this.HorizontalConfig = {
            // background: {
            //     scale: 0.89,
            //     position: cc.v2(240, 0)
            // },
            // game: {
            //     scale: 0.89,
            //     position: cc.v2(240, 0),
            //     children: {
            //     }
            // },
            // UI: {
            //     children: {
            //         paypal: {
            //             scale: 0.89,
            //             position: cc.v2(-240, 220)
            //         },
            //         banner: {
            //             scale: 0.89,
            //             position: cc.v2(-240, -210),
            //             children: {
            //                 icon: {
            //                     position: cc.v2(-130, 0)
            //                 },
            //                 logo: {
            //                     scale: 1.5,
            //                     position: cc.v2(0, 230)
            //                 },
            //                 playNow: {
            //                     position: cc.v2(90, 0)
            //                 },
            //                 adsonly: {
            //                     active: this.isApplovin
            //                 },
            //                 mtg: {
            //                     active: this.isMintegral
            //                 }
            //             }
            //         },
            //         awardPageBox: {
            //             scale: 0.65,
            //             position: cc.v2(240, 0),
            //             children: {
            //                 bg_iphone: {
            //                     scale: 0.89 / 0.65
            //                 }
            //             }
            //         },
            //         // turn_box: {
            //         //     scale: 0.65,
            //         //     position: cc.v2(240, 30),
            //         //     children: {
            //         //         bg_turn: {
            //         //             scale: 0.89 / 0.65
            //         //         }
            //         //     }
            //         // }
            //     }
            // }
        };
        this.VerticalConfig = {}
        // background: {
        //     scale: 1,
        //     position: cc.v2(0, 0)
        // },
        // game: {
        //     scale: 1,
        //     position: cc.v2(0, 0),
        // },
        // UI: {
        //     children: {
        //         paypal: {
        //             scale: 1,
        //             position: cc.v2(0, 438.821)
        //         },
        //         banner: {
        //             scale: 1,
        //             position: cc.v2(0, -420),
        //             children: {
        //                 icon: {
        //                     position: cc.v2(-210, 0)
        //                 },
        //                 logo: {
        //                     scale: 1,
        //                     position: cc.v2(-58.035, 0)
        //                 },
        //                 playNow: {
        //                     position: cc.v2(146.469, 0)
        //                 },
        //                 adsonly: {
        //                     active: this.isApplovin
        //                 },
        //                 mtg: {
        //                     active: this.isMintegral
        //                 }
        //             }
        //         },
        //         pps: {
        //         },
        //         awardPageBox: {
        //             scale: 1,
        //             position: cc.v2(0, 0),
        //             children: {
        //                 bg_iphone: {
        //                     scale: 1
        //                 }
        //             }
        //         },
        //         // turn_box: {
        //         //     scale: 1,
        //         //     position: cc.v2(0, 0),
        //         //     children: {
        //         //         bg_turn: {
        //         //             scale: 1
        //         //         }
        //         //     }
        //         // }
        //     }
        // }


        //guiding用来记录是否还需要继续进行拖动手势引导

        ;this.guideScript = null;
    }

    //设置引导脚本


    _createClass(GameModel, [{
        key: "setGuideView",
        value: function setGuideView(guideScript) {
            this.guideScript = guideScript;
        }

        //初始化游戏模型

    }, {
        key: "gameInit",
        value: function gameInit() {}
    }]);

    return GameModel;
}();

exports.default = GameModel;
module.exports = exports["default"];

cc._RF.pop();