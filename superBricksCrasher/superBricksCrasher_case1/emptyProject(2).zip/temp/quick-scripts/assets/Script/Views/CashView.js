(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Views/CashView.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '082c1rVFHVL5JJtkMozry22', 'CashView', __filename);
// Script/Views/CashView.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        cash: 0 // 当前金额
    },

    onLoad: function onLoad() {
        // 初始化参数
        this.currentCash = this.cash; // 设置初始金额
        this.targetCash = 0; // 目标金额 初始为0
        this.icon = '$ '; // 金额符号
        this.iconType = 'head'; // 符号所在位置            初始默认在头部
        this.eachAdd = 100; // 每次增加的金额              初始默认为100
        this.updatable = false; // 是否可以更新
        this.isPlus = true; // 表示为增加或者减少金额

        // 获取节点
        this.label = this.node.getComponent(cc.Label);
    },


    /** 设置符号的位置以及状态
     * @param {String} icon 设置金额的字符
     * @param {Boolean} iconType 设置字符在金额的哪个位置 有head和behind
     */
    // setIcon(icon = '$ ', iconType = 'head') {
    //     this.icon = icon;
    //     this.iconType = iconType;
    // },

    /**
     * @param {Number} num 目标金额
     * @param {*} time 达到金额所需要的时间
     */
    addCash: function addCash(num, addTime) {
        var _this = this;

        return new Promise(function (resolve, reject) {
            _this.targetCash += num; // 目标金额
            _this.addTime = addTime; // 增加时长

            _this.isPlus = _this.targetCash > _this.currentCash ? true : false;
            _this.eachAdd = Math.abs(_this.targetCash - _this.currentCash) * 0.0166666666666666 / addTime; // 每dt增加的cash
            // console.log("111111");
            _this.setUpdatable(true); // 设置为可以加钱状态
            setTimeout(function () {
                resolve();
            }, addTime);
        });
    },


    /**设置是否可以增加 */
    setUpdatable: function setUpdatable(status) {
        this.updatable = status;
    },
    update: function update(dt) {
        if (!this.updatable) return false;
        this.currentCash = this.currentCash + (this.isPlus ? this.eachAdd : -1 * this.eachAdd);
        this.cash = parseInt(this.currentCash); // 增加金币并四舍五入

        // 是否结束的判断
        if (this.isPlus ? this.currentCash >= this.targetCash : this.currentCash <= this.targetCash) {
            this.setUpdatable(false);
            this.currentCash = this.targetCash;
            this.cash = this.targetCash;
        }

        // 判断符号在前面还是后面
        if (this.iconType) {
            this.label.string = this.cash;
        } else {
            this.label.string = this.icon;
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=CashView.js.map
        