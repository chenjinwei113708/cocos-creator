(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Views/CountDownView.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'ab171QWiK9IToGXL0Clvka6', 'CountDownView', __filename);
// Script/Views/CountDownView.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {
        this.countDownViewInit();
    },


    /**初始化countDownView */
    countDownViewInit: function countDownViewInit() {
        this.time = 0; // 计时事件
        this.endTime = Infinity; // 表示结束时候需要的事件
        this.timer = null; // 记录计时器的变量
        this.callback = null; // 存放计时器到时间所需要执行的方法
        this.canRun = true; // 表示可不可以计时
    },


    /**
     * 开启计时器
     * @param {Number} endTime 结束需要的时间
     * @param {Function} cb 到了结束时间需要执行的函数
     */
    startCountDown: function startCountDown() {
        var _this = this;

        var endTime = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : undefined;
        var cb = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : undefined;

        if (!this.canRun) return false;
        // !this.canRun && this.setRunable(true)
        endTime && this.setEndTime(endTime);
        cb && (this.callback = cb);
        if (this.canRun) {
            this.timer = setTimeout(function () {
                // console.log('tiktok')
                _this.time++;
                _this.startCountDown();
                if (_this.time >= _this.endTime) {
                    _this.callback();
                    _this.stopCountDown();
                }
            }, 1000);
        } else {}
    },


    /**停止计时器 */
    stopCountDown: function stopCountDown() {
        if (this.timer) clearTimeout(this.timer);
        this.time = 0;
        // this.setRunable(false);
    },


    /**设置结束时所需要的事件 */
    setEndTime: function setEndTime(endTime) {
        this.endTime = endTime;
    },


    /**设置是否可以计时 */
    setRunable: function setRunable(status) {
        this.canRun = status;
    },
    start: function start() {}
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=CountDownView.js.map
        