(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Views/AwardView.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '891392cT0NOTphNVj2ekZLq', 'AwardView', __filename);
// Script/Views/AwardView.js

"use strict";

var _Animation = require("../Utils/Animation");

cc.Class({
  extends: cc.Component,

  properties: {
    mask: cc.Node,
    downloadMask: cc.Node, // 下载遮罩层
    awardPage: { type: cc.Node, default: null },
    buttonTip: { type: cc.Node, default: null },
    PPPage: cc.Node,
    PPPageBlur: cc.Node
  },

  /**初始化 */
  onLoad: function onLoad() {
    this.awardViewInit();
  },
  awardViewInit: function awardViewInit() {
    this.hideAwardPage; // 存储隐藏奖励页的变量
    this.gameController.setScript(this, "gameView", "audioUtils", "guideView");
  },


  /**切换遮罩层显示 */
  toggleAwardMask: function toggleAwardMask(type) {
    return (0, _Animation.toggleMask)(this.mask, type);
  },


  /**展示奖励页面 */
  showAwardPage: function showAwardPage() {
    var _this = this;

    var node = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.awardPage;

    return new Promise(function (resolve, reject) {
      _this.toggleAwardMask("in");
      (0, _Animation.scaleIn)(node).then(function () {
        _this.guideView.showHand(_this.buttonTip);
        _this.showDownloadMask();
        resolve();
      });
    });
  },
  hideAwardPage: function hideAwardPage(node) {
    var _this2 = this;

    return new Promise(function (resolve, reject) {
      // 隐藏手
      _this2.guideView.stopHand();
      _this2.toggleAwardMask("out");
      scaleOut(_this2.awardPage1).then(function () {
        resolve();
      });
    });
  },
  showDownloadMask: function showDownloadMask(cb) {
    this.downloadMask.active = true; // 点击任何地方都会进行下载
  },


  /**展示pp奖励页面 */
  showPPPage: function showPPPage(cb) {
    var _this3 = this;

    return new Promise(function (resolve, reject) {
      var moveTime = 0.4;
      var buffer = 15;
      var bufferTime = 0.3;
      var canvas = cc.find("Canvas");
      _this3.PPPage.position = cc.v2(canvas.width / 2 + _this3.PPPage.width / 2, 0); // 让其在整个页面的右边
      _this3.PPPage.active = true;
      _this3.PPPage.runAction(cc.sequence(cc.moveTo(moveTime, cc.v2(-buffer, 0)), cc.moveTo(bufferTime, cc.v2(0, 0)), cc.callFunc(function () {
        resolve();
        cb && cb();
      })));
    });
  },


  /**展示pp奖励模糊页面 */
  showPPPageBlur: function showPPPageBlur(cb) {
    var _this4 = this;

    return new Promise(function (resolve, reject) {
      var time = 0.25;
      _this4.PPPageBlur.opacity = 0;
      _this4.PPPageBlur.active = true;
      _this4.PPPageBlur.runAction(cc.sequence(cc.fadeIn(time), cc.callFunc(function () {
        resolve();
        cb && cb();
      })));
    });
  },


  /**展示下载的页面 icon 与 下载按钮 */
  showDownload: function showDownload(cb) {
    var _this5 = this;

    return new Promise(function (resolve, reject) {
      // 打开遮罩层
      // this.toggleMask(fadeInTime);
      _this5.toggleAwardMask();

      // 初始化参数
      var fadeInTime = 0.5;
      _this5.download.opacity = 0;
      _this5.download.active = true;

      // 执行运动
      _this5.download.runAction(cc.sequence(cc.fadeIn(fadeInTime), cc.callFunc(function () {
        // 执行回调
        cb && cb();
        resolve();
      })));
    });
  },


  /**收集奖励 */
  handleReceiveAward: function handleReceiveAward(cb) {
    var _this6 = this;

    return new Promise(function (resolve, reject) {
      _this6.showPPPage().then(function () {
        _this6.showPPPageBlur().then(function () {
          _this6.showDownloadMask();
          _this6.showDownload().then(function () {
            cb && cb();
            resolve();
          });
        });
      });
    });
  }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=AwardView.js.map
        