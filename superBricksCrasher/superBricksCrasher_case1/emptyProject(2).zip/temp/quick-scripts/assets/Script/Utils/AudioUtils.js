(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Utils/AudioUtils.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '01dc1k7zgBBzryGaRExFR2l', 'AudioUtils', __filename);
// Script/Utils/AudioUtils.js

"use strict";

// var audioIds = {};

cc.Class({
  extends: cc.Component,
  properties: {
    // 开启声音
    isAudioEnabled: true,

    openVolunmIcon: {
      type: cc.SpriteFrame,
      default: null
    },

    closeVolumnIcon: {
      type: cc.SpriteFrame,
      default: null
    },
    // Music
    bgMusic: {
      type: cc.AudioClip,
      default: null
    },

    // Effect
    bgClick: {
      type: cc.AudioClip,
      default: null
    },

    startMusic: {
      type: cc.AudioClip,
      default: null
    },

    endMusic: {
      type: cc.AudioClip,
      default: null
    },
    // 祝贺音效
    cheer: {
      type: cc.AudioClip,
      default: null
    },
    timing: {
      type: cc.AudioClip,
      default: null
    },
    money: {
      type: cc.AudioClip,
      default: null
    },
    spin: {
      type: cc.AudioClip,
      default: null
    },
    correct: {
      type: cc.AudioClip,
      default: null
    },
    bomb: {
      type: cc.AudioClip,
      default: null
    },
    fresh: {
      type: cc.AudioClip,
      default: null
    },
    combine: {
      type: cc.AudioClip,
      default: null
    }
  },

  onLoad: function onLoad() {},
  toggleVolumn: function toggleVolumn() {
    this.isAudioEnabled ? this.closeVolumn() : this.openVolumn();
  },
  openVolumn: function openVolumn() {
    this.isAudioEnabled = true;
    this.node.getChildByName("btn").getComponent(cc.Sprite).spriteFrame = this.openVolunmIcon;
    // Music
    this.playBgm();
  },
  closeVolumn: function closeVolumn() {
    this.isAudioEnabled = false;
    this.node.getChildByName("btn").getComponent(cc.Sprite).spriteFrame = this.closeVolumnIcon;
    cc.audioEngine.stopAll();
  },
  playBgm: function playBgm() {
    if (this.isAudioEnabled) {
      cc.audioEngine.playMusic(this.bgMusic, true);
      cc.audioEngine.setMusicVolume(0.8);
    }
  },

  /**
   *
   * @param {String} effectName 音频名
   * @param {Number} volumn 音量大小
   */
  playEffect: function playEffect(effectName, volumn) {
    // console.log('播放了', effectName);
    if (!this[effectName]) {
      throw "No audioClip " + effectName;
    }
    if (this.isAudioEnabled) {
      // 播放音效时bgm声音减低
      cc.audioEngine.setMusicVolume(0.5);
      var effectId = cc.audioEngine.play(this[effectName], false, volumn); // 新方法，调控音量更好
      // let effectId = cc.audioEngine.playEffect(this[effectName], false);
      // cc.audioEngine.setEffectsVolume(volumn);

      cc.audioEngine.setFinishCallback(effectId, function () {
        // 恢复音量
        cc.audioEngine.setMusicVolume(0.8);
      });
    }
  }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=AudioUtils.js.map
        