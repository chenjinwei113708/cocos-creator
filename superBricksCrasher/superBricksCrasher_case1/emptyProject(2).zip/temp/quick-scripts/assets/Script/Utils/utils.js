(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Utils/utils.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'bd20bYudTxGG79bT9o5PoOZ', 'utils', __filename);
// Script/Utils/utils.js

'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

// const Tools = {
// 获取数据类型
function getType(obj) {
  var type = typeof obj === 'undefined' ? 'undefined' : _typeof(obj);
  // 不等于object则表示为基础数据类型
  if (type !== 'object') return type;
  // 用正则来截取其类型部分，且变成小写
  return Object.prototype.toString.call(obj).replace(/^\[object (\S+)\]$/, $1).toLowerCase();
}

// 浅拷贝
function shallowClone(target) {
  if ((typeof target === 'undefined' ? 'undefined' : _typeof(target)) !== 'object' || target === null) return target;
  var cloneTarget = Array.isArray(target) ? [] : {};
  for (var key in target) {
    if (target.hasOwnProperty(key)) {
      cloneTarget[key] = target[key];
    }
  }
  return cloneTarget;
}

// 深拷贝
function deepClone(obj) {
  var hash = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : new WeakMap();

  if (!(((typeof obj === 'undefined' ? 'undefined' : _typeof(obj)) === 'object' || typeof obj === 'function') && obj !== null)) return obj; // 如果不是复杂类型数据，则直接返回
  // 检测是否为Date
  if (obj.constructor === Date) return new Date(obj);
  // 检测是否为正则
  if (obj.constructor === RegExp) return new RegExp(obj);
  // 检测是否是循环对象
  if (hash.has(obj)) return hash.get(obj);
  // 浅拷贝一个放进hash
  var cloneObj = Object.create(Reflect.getPrototypeOf(obj), Object.getOwnPropertyDescriptors(obj));
  hash.set(obj, cloneObj);
  // 递归复制
  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = Reflect.ownKeys(obj)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var key = _step.value;

      cloneObj[key] = deepClone(obj[key], hash);
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator.return) {
        _iterator.return();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  return cloneObj;
}

// 只能传入时间戳或者
function timeFormat() {
  var time = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : new Date();

  if (!(time instanceof Date) && time.toString().length === 13 && !(time.toString().indexOf('.') > -1)) {
    time = new Date(Number(time));
  }
  var y = time.getFullYear(); //getFullYear方法以四位数字返回年份
  var M = time.getMonth() + 1; // getMonth方法从 Date 对象返回月份 (0 ~ 11)，返回结果需要手动加一
  var d = time.getDate(); // getDate方法从 Date 对象返回一个月中的某一天 (1 ~ 31)
  var h = time.getHours(); // getHours方法返回 Date 对象的小时 (0 ~ 23)
  var m = time.getMinutes(); // getMinutes方法返回 Date 对象的分钟 (0 ~ 59)
  var s = time.getSeconds(); // getSeconds方法返回 Date 对象的秒数 (0 ~ 59)
  return y + '-' + M + '-' + d + ' ' + h + ':' + m + ':' + s;
}

// 获取随机数
function getRandom(min, max) {
  if (!(typeof min === 'number' || typeof max === 'number')) return console.log('getRandom: 请传入数字');
  min = Math.floor(min);
  max = Math.ceil(max);
  return Math.floor(Math.random() * (max - min + 1) + min);
}

/**节流函数 */
function getThrottle(fn) {
  var delay = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 100;

  var timer = null;
  return function () {
    var _this = this; // 执行这个函数所在的this
    if (timer) return false;

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    fn.apply(_this, args); // 让其先执行
    timer = setTimeout(function () {
      clearTimeout(timer);
      timer = null;
    }, delay);
  };
}
// }

exports.getType = getType;
exports.shallowClone = shallowClone;
exports.deepClone = deepClone;
exports.timeFormat = timeFormat;
exports.getRandom = getRandom;
exports.getThrottle = getThrottle;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=utils.js.map
        