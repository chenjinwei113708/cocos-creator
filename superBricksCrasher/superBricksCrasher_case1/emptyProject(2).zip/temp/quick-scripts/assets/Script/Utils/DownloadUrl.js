(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Utils/DownloadUrl.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'cb911X38xpJjZfNa+N1dTtT', 'DownloadUrl', __filename);
// Script/Utils/DownloadUrl.js

'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
var DownloadUrl = exports.DownloadUrl = {
    iosUrl: 'https://apps.apple.com/app/id1547566715',
    androidUrl: 'https://apps.apple.com/app/id1547566715',

    getUrl: function getUrl() {
        var userAgent = navigator.userAgent || navigator.vendor;
        if (/(iPhone|iPad|iPod|iOS|Mac OS X)/i.test(userAgent)) {
            userAgent = 'ios';
        } else {
            userAgent = 'android';
        }
        return userAgent === 'ios' ? this.iosUrl : this.androidUrl;
    }
};

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=DownloadUrl.js.map
        