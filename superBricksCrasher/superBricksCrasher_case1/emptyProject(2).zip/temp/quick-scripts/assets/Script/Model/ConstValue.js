(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Model/ConstValue.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '355ffopD5ZHd4ZZTRyYt0Io', 'ConstValue', __filename);
// Script/Model/ConstValue.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
/**
 * 这个脚本用来存储一些全局都会用到的常量
 */
var GAME_INFO = {};

var GAME_STATUS = {
    DISABLED: 0,
    CAN_CLICK1: 1
};

exports.GAME_INFO = GAME_INFO;
exports.GAME_STATUS = GAME_STATUS;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=ConstValue.js.map
        